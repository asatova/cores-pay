<?php
/**
 * Main Plugin Class
 * 
 * @package CoresPay
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Cores_Pay {
    
    /**
     * Plugin instance
     * 
     * @var Cores_Pay
     */
    private static $instance = null;
    
    /**
     * Get plugin instance
     * 
     * @return Cores_Pay
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required dependencies
     */
    private function load_dependencies() {
        require_once CORES_PAY_PLUGIN_PATH . 'includes/class-cores-pay-shortcode.php';
        
        if (is_admin()) {
            require_once CORES_PAY_PLUGIN_PATH . 'includes/class-cores-pay-admin.php';
        }
    }
    
    /**
     * Initialize WordPress hooks
     */
    private function init_hooks() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
    }
    
    /**
     * Initialize plugin components
     */
    public function init() {
        new Cores_Pay_Shortcode();
        
        if (is_admin()) {
            new Cores_Pay_Admin();
        }
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        // Enqueue CSS
        wp_enqueue_style(
            'cores-pay-style',
            CORES_PAY_PLUGIN_URL . 'assets/css/cores-pay.css',
            array(),
            CORES_PAY_VERSION
        );
        
        // Enqueue JavaScript
        wp_enqueue_script(
            'cores-pay-script',
            CORES_PAY_PLUGIN_URL . 'assets/js/cores-pay.js',
            array('jquery'),
            CORES_PAY_VERSION,
            true
        );
        
        // Localize script
        wp_localize_script('cores-pay-script', 'coresPayData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cores_pay_nonce'),
            'errorMessage' => __('Invoice URL is not configured. Please set it in the admin panel.', 'cores-pay')
        ));
    }
    
    /**
     * Load plugin textdomain for translations
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'cores-pay',
            false,
            dirname(CORES_PAY_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Plugin activation callback
     */
    public static function activate() {
        // Set default options
        add_option('cores_pay_invoice_url', '');
        add_option('cores_pay_button_text', __('Payment Link', 'cores-pay'));
        add_option('cores_pay_version', CORES_PAY_VERSION);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation callback
     */
    public static function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
?>