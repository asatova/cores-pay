<?php
/**
 * Admin Panel Class
 * 
 * @package CoresPay
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Cores_Pay_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_filter('plugin_action_links_' . CORES_PAY_PLUGIN_BASENAME, array($this, 'add_action_links'));
    }
    
    /**
     * Add admin menu page
     */
    public function add_admin_menu() {
        add_options_page(
            __('Cores Pay Settings', 'cores-pay'),
            __('Cores Pay', 'cores-pay'),
            'manage_options',
            'cores-pay-settings',
            array($this, 'render_admin_page')
        );
    }
    
    /**
     * Register plugin settings
     */
    public function register_settings() {
        // Register settings
        register_setting(
            'cores_pay_settings',
            'cores_pay_invoice_url',
            array(
                'type' => 'string',
                'sanitize_callback' => 'esc_url_raw',
                'default' => ''
            )
        );
        
        register_setting(
            'cores_pay_settings',
            'cores_pay_button_text',
            array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default' => __('Payment Link', 'cores-pay')
            )
        );
        
        // Add settings section
        add_settings_section(
            'cores_pay_main_section',
            __('Main Settings', 'cores-pay'),
            array($this, 'render_section_description'),
            'cores-pay-settings'
        );
        
        // Add settings fields
        add_settings_field(
            'cores_pay_invoice_url',
            __('Invoice URL', 'cores-pay'),
            array($this, 'render_invoice_url_field'),
            'cores-pay-settings',
            'cores_pay_main_section'
        );
        
        add_settings_field(
            'cores_pay_button_text',
            __('Button Text', 'cores-pay'),
            array($this, 'render_button_text_field'),
            'cores-pay-settings',
            'cores_pay_main_section'
        );
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Display success message if settings were saved
        if (isset($_GET['settings-updated'])) {
            add_settings_error(
                'cores_pay_messages',
                'cores_pay_message',
                __('Settings Saved', 'cores-pay'),
                'updated'
            );
        }
        
        // Show error/update messages
        settings_errors('cores_pay_messages');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('cores_pay_settings');
                do_settings_sections('cores-pay-settings');
                submit_button(__('Save Settings', 'cores-pay'));
                ?>
            </form>
            
            <?php $this->render_usage_guide(); ?>
        </div>
        <?php
    }
    
    /**
     * Render section description
     */
    public function render_section_description() {
        echo '<p>' . __('Configure your payment button settings below.', 'cores-pay') . '</p>';
    }
    
    /**
     * Render invoice URL field
     */
    public function render_invoice_url_field() {
        $value = get_option('cores_pay_invoice_url', '');
        ?>
        <input 
            type="url" 
            name="cores_pay_invoice_url" 
            value="<?php echo esc_attr($value); ?>" 
            class="regular-text" 
            placeholder="https://example.com/invoice"
        />
        <p class="description">
            <?php _e('Enter the URL where users will be redirected for payment.', 'cores-pay'); ?>
        </p>
        <?php
    }
    
    /**
     * Render button text field
     */
    public function render_button_text_field() {
        $value = get_option('cores_pay_button_text', __('Payment Link', 'cores-pay'));
        ?>
        <input 
            type="text" 
            name="cores_pay_button_text" 
            value="<?php echo esc_attr($value); ?>" 
            class="regular-text"
        />
        <p class="description">
            <?php _e('Enter the text to display on the payment button.', 'cores-pay'); ?>
        </p>
        <?php
    }
    
    /**
     * Render usage guide
     */
    private function render_usage_guide() {
        ?>
        <div class="card" style="margin-top: 20px; max-width: 800px;">
            <h2><?php _e('How to Use', 'cores-pay'); ?></h2>
            
            <h3><?php _e('Basic Usage', 'cores-pay'); ?></h3>
            <p><?php _e('Add the following shortcode to any post or page:', 'cores-pay'); ?></p>
            <pre><code>[cores_pay]</code></pre>
            
            <h3><?php _e('With Custom Parameters', 'cores-pay'); ?></h3>
            <pre><code>[cores_pay url="https://example.com/invoice" text="Pay Now" target="_self"]</code></pre>
            
            <h3><?php _e('Available Parameters', 'cores-pay'); ?></h3>
            <ul style="list-style: disc; margin-left: 20px;">
                <li>
                    <strong>url</strong> - <?php _e('The invoice page URL (overrides the setting above)', 'cores-pay'); ?>
                </li>
                <li>
                    <strong>text</strong> - <?php _e('Button text (overrides the setting above)', 'cores-pay'); ?>
                </li>
                <li>
                    <strong>target</strong> - <?php _e('Link target: _blank (new tab) or _self (same tab)', 'cores-pay'); ?>
                </li>
                <li>
                    <strong>class</strong> - <?php _e('Additional CSS class for custom styling', 'cores-pay'); ?>
                </li>
            </ul>
            
            <h3><?php _e('Example in PHP Template', 'cores-pay'); ?></h3>
            <pre><code>&lt;?php echo do_shortcode('[cores_pay]'); ?&gt;</code></pre>
        </div>
        <?php
    }
    
    /**
     * Add action links to plugin page
     * 
     * @param array $links Existing plugin action links
     * @return array Modified plugin action links
     */
    public function add_action_links($links) {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            admin_url('options-general.php?page=cores-pay-settings'),
            __('Settings', 'cores-pay')
        );
        
        array_unshift($links, $settings_link);
        
        return $links;
    }
}
?>