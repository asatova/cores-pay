<?php
/**
 * Cores Pay Plugin Uninstall
 * 
 * This file runs when the plugin is deleted from WordPress.
 */

// Exit if uninstall not called from WordPress
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/**
 * Delete plugin options
 */
function cores_pay_delete_options() {
    delete_option('cores_pay_invoice_url');
    delete_option('cores_pay_button_text');
    delete_option('cores_pay_version');
}

// Single site
cores_pay_delete_options();

// Multisite
if (is_multisite()) {
    $sites = get_sites(array('number' => 0));
    
    foreach ($sites as $site) {
        switch_to_blog($site->blog_id);
        cores_pay_delete_options();
        restore_current_blog();
    }
}

// Clear any cached data
wp_cache_flush();
?>