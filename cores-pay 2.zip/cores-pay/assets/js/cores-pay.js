/**
 * Cores Pay Plugin JavaScript
 * 
 * @package CoresPay
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    /**
     * Initialize plugin when DOM is ready
     */
    $(document).ready(function() {
        CoresPayButton.init();
    });
    
    /**
     * Cores Pay Button Handler
     */
    var CoresPayButton = {
        
        /**
         * Initialize button handlers
         */
        init: function() {
            this.bindEvents();
            this.storeOriginalText();
        },
        
        /**
         * Bind click events to buttons
         */
        bindEvents: function() {
            $(document).on('click', '[data-cores-pay-button]', function(e) {
                CoresPayButton.handleClick(e, $(this));
            });
        },
        
        /**
         * Store original button text
         */
        storeOriginalText: function() {
            $('[data-cores-pay-button]').each(function() {
                var $button = $(this);
                if (!$button.data('original-text')) {
                    $button.data('original-text', $button.text());
                }
            });
        },
        
        /**
         * Handle button click
         * 
         * @param {Event} e Click event
         * @param {jQuery} $button Button element
         */
        handleClick: function(e, $button) {
            var url = $button.attr('href');
            
            // Validate URL
            if (!this.isValidUrl(url)) {
                e.preventDefault();
                this.showError($button);
                return false;
            }
            
            // Add loading state
            this.setLoadingState($button, true);
            
            // Reset loading state if staying on same page
            if ($button.attr('target') !== '_blank') {
                setTimeout(function() {
                    CoresPayButton.setLoadingState($button, false);
                }, 2000);
            }
        },
        
        /**
         * Check if URL is valid
         * 
         * @param {string} url URL to validate
         * @return {boolean} Whether URL is valid
         */
        isValidUrl: function(url) {
            return url && url !== '#' && url !== '';
        },
        
        /**
         * Show error message
         * 
         * @param {jQuery} $button Button element
         */
        showError: function($button) {
            var message = typeof coresPayData !== 'undefined' && coresPayData.errorMessage
                ? coresPayData.errorMessage
                : 'Invoice URL is not configured. Please set it in the admin panel.';
            
            // Try WordPress notices API first
            if (typeof wp !== 'undefined' && wp.notices) {
                wp.notices.create({
                    message: message,
                    type: 'error',
                    isDismissible: true
                });
            } else {
                // Fallback to alert
                alert(message);
            }
            
            // Add error class
            $button.addClass('error').removeClass('loading');
            
            // Remove error class after delay
            setTimeout(function() {
                $button.removeClass('error');
            }, 3000);
        },
        
        /**
         * Set button loading state
         * 
         * @param {jQuery} $button Button element
         * @param {boolean} isLoading Whether button is loading
         */
        setLoadingState: function($button, isLoading) {
            var originalText = $button.data('original-text') || $button.text();
            
            if (isLoading) {
                $button
                    .addClass('loading')
                    .data('original-text', originalText)
                    .text('Loading...');
            } else {
                $button
                    .removeClass('loading')
                    .text(originalText);
            }
        }
    };
    
    /**
     * Expose to global scope if needed
     */
    window.CoresPayButton = CoresPayButton;
    
})(jQuery);

