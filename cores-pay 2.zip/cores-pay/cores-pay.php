<?php
/**
 * Plugin Name: Cores Pay
 * Plugin URI: https://example.com
 * Description: Payment link button with shortcode plugin
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: cores-pay
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('CORES_PAY_VERSION', '1.0.0');
define('CORES_PAY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CORES_PAY_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('CORES_PAY_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Load main plugin class
require_once CORES_PAY_PLUGIN_PATH . 'includes/class-cores-pay.php';

/**
 * Initialize the plugin
 */
function cores_pay_init() {
    new Cores_Pay();
}
add_action('plugins_loaded', 'cores_pay_init');

/**
 * Activation hook
 */
register_activation_hook(__FILE__, array('Cores_Pay', 'activate'));

/**
 * Deactivation hook
 */
register_deactivation_hook(__FILE__, array('Cores_Pay', 'deactivate'));
?>