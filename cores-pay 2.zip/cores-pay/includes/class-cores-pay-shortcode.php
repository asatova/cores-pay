<?php
/**
 * Shortcode Handler Class
 * 
 * @package CoresPay
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Cores_Pay_Shortcode {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_shortcode('cores_pay', array($this, 'render_shortcode'));
    }
    
    /**
     * Render shortcode output
     * 
     * @param array $atts Shortcode attributes
     * @return string HTML output
     */
    public function render_shortcode($atts) {
        // Parse shortcode attributes
        $atts = shortcode_atts(array(
            'url' => get_option('cores_pay_invoice_url', '#'),
            'text' => get_option('cores_pay_button_text', __('Payment Link', 'cores-pay')),
            'class' => 'cores-pay-button',
            'target' => '_blank'
        ), $atts, 'cores_pay');
        
        // Sanitize attributes
        $atts = $this->sanitize_attributes($atts);
        
        // Generate and return HTML
        return $this->generate_button_html($atts);
    }
    
    /**
     * Sanitize shortcode attributes
     * 
     * @param array $atts Attributes to sanitize
     * @return array Sanitized attributes
     */
    private function sanitize_attributes($atts) {
        return array(
            'url' => esc_url($atts['url']),
            'text' => sanitize_text_field($atts['text']),
            'class' => sanitize_html_class($atts['class']),
            'target' => in_array($atts['target'], array('_blank', '_self', '_parent', '_top')) ? $atts['target'] : '_blank'
        );
    }
    
    /**
     * Generate button HTML
     * 
     * @param array $atts Button attributes
     * @return string HTML output
     */
    private function generate_button_html($atts) {
        $output = '<div class="cores-pay-wrapper">';
        $output .= sprintf(
            '<a href="%s" class="%s" target="%s" rel="%s" data-cores-pay-button>%s</a>',
            esc_url($atts['url']),
            esc_attr($atts['class']),
            esc_attr($atts['target']),
            $atts['target'] === '_blank' ? 'noopener noreferrer' : '',
            esc_html($atts['text'])
        );
        $output .= '</div>';
        
        return $output;
    }
}
?>